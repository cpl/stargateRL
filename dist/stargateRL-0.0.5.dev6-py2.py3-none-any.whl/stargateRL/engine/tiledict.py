"""Dicionaries for sets of tiles inside GxTilesets."""
