"""Primitive objects (shapes+), using vertices."""
