"""Draw ascii text files as sprite art."""
