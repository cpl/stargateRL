|mylogo|
~~~~~~~~
stargateRL |pypi| |travis| |landscape| |coveralls| |gitter|
===========================================================
.. |coveralls| image:: https://coveralls.io/repos/github/thee-engineer/stargateRL/badge.svg?branch=master
  :target: https://coveralls.io/github/thee-engineer/stargateRL?branch=master
  :alt: Coveralls
.. |landscape| image:: https://landscape.io/github/thee-engineer/stargateRL/master/landscape.svg?style=flat
   :target: https://landscape.io/github/thee-engineer/stargateRL/master
   :alt: Code Health
.. |travis| image:: https://travis-ci.org/thee-engineer/stargateRL.svg?branch=master
    :target: https://travis-ci.org/thee-engineer/stargateRL
    :alt: Travis-CI
.. |pypi| image:: https://badge.fury.io/py/stargateRL.svg
    :target: https://badge.fury.io/py/stargateRL
    :alt: PyPi Project Page
.. |gitter| image:: https://img.shields.io/gitter/room/nwjs/nw.js.svg
    :target: https://gitter.im/stargateRL/Lobby
    :alt: Gitter Chat
.. |mylogo| image:: http://i.imgur.com/MgTkIlm.png


